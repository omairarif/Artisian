var $title = $("#title");
var $duration = $("#duration");
var $amount = $("#amount");
var $skill = $("#skill");
var $description = $("#description");

var getUrlParameter = function getUrlParameter(sParam) {
    var sPageURL = window.location.search.substring(1),
        sURLVariables = sPageURL.split('&'),
        sParameterName,
        i;

    for (i = 0; i < sURLVariables.length; i++) {
        sParameterName = sURLVariables[i].split('=');

        if (sParameterName[0] === sParam) {
            return sParameterName[1] === undefined ? true : decodeURIComponent(sParameterName[1]);
        }
    }
};


function submitButtonAction() {
    
  
alert('My name is Khan' + getUrlParameter('id'));

    jQuery.ajax({
      url: "http://127.0.0.1:3000/jobs",
      type: "GET",
      dataType: "json",
      headers: {
        "Content-Type": "application/json; charset=utf-8",
      },
      contentType: "application/json",
      data: JSON.stringify({
        "title": $title.val(),
        "duration": $duration.val(),
        "amount": $amount.val(),
        "skill_id": 1,
        "description" : description.val(),
        "client_id" : 1,
      })
    })
    
      .done(function (data, textStatus, jqXHR) {
        console.log("HTTP Request Succeeded: " + jqXHR.status);
        console.log(data);
        alert("Job Successfully Added " + data.title);
        window.location.replace("../profilebootstrap/indexx.html?id=");
      })
      .fail(function (jqXHR, textStatus, errorThrown) {
        console.log("HTTP Request Failed");
        alert("Either email or password is incorrect " + errorThrown);
      })
      .always(function () {
        /* ... */
        alert("Either email or password is incorrect " + errorThrown);
      });
  }